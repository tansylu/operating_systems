#include <stdio.h>

#include <stdlib.h>

#include <unistd.h>

#include <string.h>

#include <sys/wait.h>

#include <fcntl.h>

#include <errno.h>



int main(int argc, char *argv[]) {

    printf("I’m SHELL process, with PID: %d - Main command is: man ping | grep -A 5 -m 1 -- -f\n", getpid());



    int fd[2];

    if (pipe(fd) == -1) {

        perror("Pipe Failed");

        return 1;

    }



    int r1 = fd[0];

    int w1 = fd[1];

    int output_file = open("output.txt", O_CREAT| O_WRONLY);

    if (output_file == -1) {

        perror("open");

        return 1;

    }



    int pid_1 = fork();

    if (pid_1 == -1) {

        perror("fork");

        return 1;

    }

    if (pid_1 == 0) {

        printf("I’m MAN process, with PID: %d - My command is: man ping\n", getpid());

        close(r1);

        dup2(w1, STDOUT_FILENO);

        close(w1);



        char *const argv[] = {"man", "ping", NULL};

        char *const envp[] = {NULL};

        execve("/usr/bin/man", argv, envp);

        perror("execve");

        return 1;

    }



    close(w1);



    int pid_2 = fork();

    if (pid_2 == -1) {

        perror("fork");

        return 1;

    }

    if (pid_2 == 0) {

        printf("I’m GREP process, with PID: %d - My command is: grep -A 5 -m 1 -- -f\n", getpid());

        dup2(r1, STDIN_FILENO);

        dup2(output_file, STDOUT_FILENO);

        close(r1);



        char *const argv[] = {"grep", "-A", "5", "-m", "1", "--", "-f", NULL};

        char *const envp[] = {NULL};

        execve("/usr/bin/grep", argv, envp);

        perror("execve");

        return 1;

    }



    close(r1);



    int status;

    waitpid(pid_1, &status, 0);

    waitpid(pid_2, &status, 0);



    close(output_file);



    printf("I’m SHELL process, with PID: %d - execution is completed, you can find the results in output.txt\n", getpid());



    return 0;

}

